#!/usr/bin/env bash

pac=$(checkupdates | wc -l)
aur=$(cower -u | wc -l)

check=$((pac + aur))
if [[ "$check" > "0" ]]; then
  echo %{F#131313}$pac %{F#131313}%{F#131313} $aur

fi
