#!/usr/bin/env bash

online=$(ip addr | grep "state UP" | cut -d ":" -f2)

icon=""

if [[ "$online" ]]; then
    echo %{F#131313}${icon}
  else
    echo %{F#131313}${icon}; sleep 0.5; echo %{F#E64141}${icon}
fi
